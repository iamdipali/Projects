import { Injectable } from '@angular/core';
import { Subject } from 'rxjs';
import { LoginComponent } from 'src/app/component/login/login.component';

@Injectable({
  providedIn: 'root'
})
export class EventService {
  headerClicked = new Subject<LoginComponent>();

  constructor() { }
}
