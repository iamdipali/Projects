import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AboutUsComponent } from './component/about-us/about-us.component';
import { FlightBookingComponent } from './component/flight-booking/flight-booking.component';
import { FlightDetailsComponent } from './component/flight-details/flight-details.component';
import { FlightHistoryComponent } from './component/flight-history/flight-history.component';
import { FlightTicketsComponent } from './component/flight-tickets/flight-tickets.component';
import { FlightsComponent } from './component/flights/flights.component';
import { HomeComponent } from './component/home/home.component';
import { LoginComponent } from './component/login/login.component';
import { RegisterComponent } from './component/register/register.component';
import { ViewBookingComponent } from './component/view-booking/view-booking.component';
import { AddFlightComponent } from './component/add-flight/add-flight.component';
import { ContactComponent } from './component/contact/contact.component';
import { AllFlightHistoryComponent } from './component/all-flight-history/all-flight-history.component';

const routes: Routes = [
  { path: '', component: HomeComponent},
  {
    path: 'login',
    component: LoginComponent
  },
  {
    path: 'rf',
    component: RegisterComponent
  },
  {
    path: 'home',
    component: HomeComponent
  },
  {
    path: 'flight-booking',
    component: FlightBookingComponent
  },
  {
    path: 'flights',
    component: FlightsComponent
  },
  {
    path: 'flight-details',
    component: FlightDetailsComponent
  },
  {
    path: 'flight-tickets',
    component: FlightTicketsComponent
  },
  {
    path: 'view-bookings',
    component: ViewBookingComponent
  },
  {
    path: 'flight-history',
    component: FlightHistoryComponent
  },
  {
    path: 'all-flight-history',
    component: AllFlightHistoryComponent
  },
  {
    path: 'about-us',
    component: AboutUsComponent
  },
  {
    path: 'contact',
    component: ContactComponent
  },
  {
    path: 'add-flight',
    component: AddFlightComponent
  }
 
 
 
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
