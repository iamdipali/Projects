import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HeaderComponent } from './component/header/header.component';
import { FooterComponent } from './component/footer/footer.component';
import { LoginComponent } from './component/login/login.component';
import { RegisterComponent } from './component/register/register.component';
import { FormsModule } from '@angular/forms';
import { HomeComponent } from './component/home/home.component';
import { HttpClientModule } from '@angular/common/http';
import { FlightBookingComponent } from './component/flight-booking/flight-booking.component';
import { FlightsComponent } from './component/flights/flights.component';
import { FlightDetailsComponent } from './component/flight-details/flight-details.component';
import { FlightTicketsComponent } from './component/flight-tickets/flight-tickets.component';
import { ViewBookingComponent } from './component/view-booking/view-booking.component';
import { FlightHistoryComponent } from './component/flight-history/flight-history.component';
import { AboutUsComponent } from './component/about-us/about-us.component';
import { AddFlightComponent } from './component/add-flight/add-flight.component';
import { ContactComponent } from './component/contact/contact.component';
import { AllFlightHistoryComponent } from './component/all-flight-history/all-flight-history.component';
import {Ng2SearchPipeModule} from 'ng2-search-filter';
import { ManjiriComponent } from './component/manjiri/manjiri.component';


@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    FooterComponent,
    LoginComponent,
    RegisterComponent,
    HomeComponent,
    FlightBookingComponent,
    FlightsComponent,
    FlightDetailsComponent,
    FlightTicketsComponent,
    ViewBookingComponent,
    FlightHistoryComponent,
    AboutUsComponent,
    AddFlightComponent,
    ContactComponent,
    AllFlightHistoryComponent,
    ManjiriComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule,
    Ng2SearchPipeModule
    
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
