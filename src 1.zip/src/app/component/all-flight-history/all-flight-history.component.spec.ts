import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AllFlightHistoryComponent } from './all-flight-history.component';

describe('AllFlightHistoryComponent', () => {
  let component: AllFlightHistoryComponent;
  let fixture: ComponentFixture<AllFlightHistoryComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AllFlightHistoryComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AllFlightHistoryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
