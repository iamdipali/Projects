import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-flight-details',
  templateUrl: './flight-details.component.html',
  styleUrls: ['./flight-details.component.css']
})
export class FlightDetailsComponent implements OnInit {

  apiUrl:string="http://localhost:3000/SeatDataGet";
  flightDetails:any=[];

  constructor(private router: Router,private http:HttpClient) { }

  ngOnInit(): void {
    this.getSeatDetails();
  }

  getSeatDetails(){
    this.http.get(this.apiUrl).subscribe((res:any)=>{

      console.log("Post res:",res);

      this.flightDetails=res.SeatDetails;

    })
  }
  
  handleBookFlight() {
    this.router.navigate(['/flight-tickets']);
  }
}
