import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import {v4 as uuidv4} from 'uuid';
import { Types } from 'mongoose';


@Component({
  selector: 'app-flight-tickets',
  templateUrl: './flight-tickets.component.html',
  styleUrls: ['./flight-tickets.component.css']
})
export class FlightTicketsComponent implements OnInit {
  isEconomyCLass:boolean = false;
  isBusinessClass:boolean= false;
  isFirstClass:boolean= false;

  isEconomy:boolean = false;
  isBusiness:boolean = false;
  isFirst:boolean = false;

  economyPrice:number = 1200;
  businessPrice:number = 1300;
  firstPrice:number = 1400;

  businessClassTickets:number = 0;
  totalticketPrice:number=0;

  UniqueId!:string;
  TicketNo!:string;

  apiUrl:string= "http://localhost:3000/bookingFlight"
  data!: { FlightName: string; UserId: any; 
    Pname: string; age: number; UniqueId: string; 
    Mobile: string | null; date: Date; FlyFrom: string; 
    FlyTo: string; Activestatus: number; Fclass: string | undefined; 
    Ptotal: number; Tamt: number; TotalPrice: number;
    BokingStatus: boolean; TicketNo: string; };

  constructor( private router: Router,private http: HttpClient) { }

  ngOnInit(): void {
  }
  bookFlight() {
    this.router.navigate(['/flight-history']);
  }

 // show hide method 
  economyClick(evnt:any){
    this.isBusiness = false;
    this.isFirst= false
    debugger;
    if(!this.isEconomyCLass){
      this.isEconomyCLass = true;
      this.isEconomy = true;
    }else{
      this.isEconomyCLass = false;
    }   
    this.isBusinessClass = false;
    this.isFirstClass = false;

  }

   // show hide method 
   businessClick(evnt1:any){
    this.isEconomy = false
    this.isFirst= false
    if(!this.isBusinessClass){
      this.isBusiness = true;
      this.isBusinessClass = true;
    }else{
      this.isBusinessClass = false;
    }   
    this.isEconomyCLass = false;
    this.isFirstClass = false;

  }


   // show hide method 
   firsClassClick(evnt2:any){
    this.isEconomy = false
    this.isBusiness = false;

    if(!this.isFirstClass){
      this.isFirst= true
      this.isFirstClass = true;
    }else{
      this.isFirstClass = false;
    } 
    this.isEconomyCLass = false;
    this.isBusinessClass = false;
  }

  calculateData(){
    //debugger;
    if(this.isEconomy){
      this.totalticketPrice = this.economyPrice * this.businessClassTickets
    }
    if(this.isBusiness){
      this.totalticketPrice = this.businessPrice * this.businessClassTickets
    }
    if(this.isFirst){
      this.totalticketPrice = this.firstPrice * this.businessClassTickets
    }
  }

  bookTicket(){
    let ticketPrice= 0;
    let calassNames;  
    debugger;
    if(this.isEconomy){
      ticketPrice= this.economyPrice 
      calassNames='Economy Class';
    }
    if(this.isBusiness){
      ticketPrice= this.businessPrice
      calassNames='Business Class';

    }
    if(this.isFirst){
      ticketPrice= this.firstPrice
      calassNames='First Class';
    }
    let myuuid = uuidv4();
 
    for (let i = 0; i < Number(this.businessClassTickets); i++) {
      let x = Math.floor((Math.random() * 40) + 1);
      let ticketNummber =  myuuid + '-' +x;

      

      //debugger;
       this.data = {
        FlightName: 'Go Fast',
        UserId:localStorage.getItem('id'),
        Pname: 'Passenger',
        age:24,
        UniqueId: myuuid,
        Mobile: localStorage.getItem('Phone_Number') ,
        date: new Date() ,
        FlyFrom: 'Pune',
        FlyTo: 'Mumbai' ,
        Activestatus: 1,
        Fclass: calassNames,
        Ptotal:Number(this.businessClassTickets) ,
        Tamt:ticketPrice ,
        TotalPrice: this.totalticketPrice ,
        BokingStatus: true,
        TicketNo:ticketNummber ,
      }
      this.http.post(this.apiUrl, this.data).subscribe((res:any) =>
      {     
          debugger;          
  
      })
      
    }
    this.router.navigate(['/view-bookings',this.data]);
    console.log(this.data);
  }


}
