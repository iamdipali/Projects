import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import Swal from 'sweetalert2';
import { EventService } from 'src/app/event/services/event.service';
import { Types } from 'mongoose';


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  user: any[] | undefined;
  username: string | undefined;
  password: string | undefined;
  rememberMe: boolean = false;
  isLogin:boolean= true;

  displayModal = false;
  apiUrl:string= "http://localhost:3000/login"

  constructor(private router: Router, private http: HttpClient, private event: EventService) { }

  ngOnInit(): void {
  }

  login(event:any){
    const newData = {
      Email: this.username,
      Password: this.password,      
    };

    this.http.post(this.apiUrl, newData).subscribe((res:any) =>
    {
      debugger;
      if(res.Success == "Login successfull!"){
        console.log("Post res : ", res); 
        this.setValueInLocalStorage(res);
        this.successNotification(res);
        this.event.headerClicked.next(this);

      }else if (res.Success == "Wrong password!"){
        Swal.fire(res.Success);
      }else{
        Swal.fire(res.Success);
      }

    })
  }

  successNotification(res:any) {
    Swal.fire('WelCome To Capg Airlines',  res.Success, 'success');
    this.router.navigate(["/home"]);
  }

  setValueInLocalStorage(res:any){

    console.log("Set Value in local Storage");
    localStorage.setItem('id', res.body._id);
    localStorage.setItem('isLogin', this.isLogin.toString());
    localStorage.setItem('Name', res.body.Name);
    localStorage.setItem('Email', res.body.Email);
    localStorage.setItem('Phone_Number', res.body.Phone_Number);
    localStorage.setItem('role', res.body.role);
  }
  
}
