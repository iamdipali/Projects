import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';


@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
  user!: any[];//Array
  name!: string;
  email!: string;
  phoneNo!: string;
  password!: string;
  repeatPassword!: string;
  rememberMe!: boolean;
  apiUrl:string= "http://localhost:3000/register"

  displayModal = false;
  
  constructor(  private router: Router, private http: HttpClient) {
    this.user = [];
    this.name = '';
    this.email = '';
    this.phoneNo = '';
    this.password = '';
    this.repeatPassword = '';
    this.rememberMe = false;
   }

  ngOnInit(): void {
  }

  handleFormSubmit(event: Event) {
    event.preventDefault();
    debugger;
    if (this.password !== this.repeatPassword) {
      // this.toastr.error('Error', 'Password not matched');
      return console.log('Password not matched');
    }

    // Getting username from email
    const username = this.email.split('@')[0];

    //Storing data in newData Variable
    const newData = {
      Name: this.name,
      Email: this.email,
      Phone_Number: this.phoneNo,
      Password: this.password,
      Repeat_Password: this.repeatPassword,
      role:1      
    };

    this.http.post(this.apiUrl, newData).subscribe((res:any) =>
    {
      // this.bookingDetailsOfCustomer = res.expenses;
    this.email = '';
    this.name='';
    this.phoneNo = '';
    this.password = '';
    this.repeatPassword = '';
    this.rememberMe = false;
   console.log("Post res : ", res);
   alert("Registration Successfull...!");
        
    })

    this.displayModal = true;
    // this.userService.signupUser(newData).subscribe(
    //   (result: any) => {
    //     console.log(result);
    //     if (result.isDone) {
    //       console.log('Account Created Successfully');

    //       this.name = '';
    //       this.email = '';
    //       this.phoneNo = '';
    //       this.password = '';
    //       this.repeatPassword = '';
    //       this.rememberMe = false;

    //       this.toastr.success('Account Created Successfully', 'Please Login');
    //     } else {
    //       console.log('Error', result.err.writeErrors[0].errmsg);
    //       this.toastr.error('Error', result.err.writeErrors[0].errmsg);
    //     }
    //     this.displayModal = false;
    //   },
    //   (error) => {
    //     console.log('Error Occured: ', error.error.msg);
    //     this.toastr.error('Error', error.error.msg);
    //     this.displayModal = false;
    //   }
    // );
  }

}
