import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { EventService } from 'src/app/event/services/event.service';
import { LoginComponent } from '../login/login.component';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {
  displayWelcomeHeader: boolean | undefined;

  imageSrc = 'assets/Images/menu2.png';
  user: any[] | undefined;
  adminRole: any;
  isLogin:boolean =false;
  adminRoles!:string;
  customerName: string | null | undefined;

  constructor( private router: Router, private event: EventService) {
    event.headerClicked.subscribe(
      (header: LoginComponent) => {
        console.log("Header clicked");
        this.isLogin = Boolean(localStorage.getItem('isLogin'));
        this.adminRole = localStorage.getItem("role");
        this.customerName = localStorage.getItem("Name");

      }
    );
    this.isLogin = Boolean(localStorage.getItem('isLogin'));
    this.adminRole = localStorage.getItem("role");
    this.customerName = localStorage.getItem("Name");
    debugger;
   }

  ngOnInit(): void {
    if (localStorage.getItem('displayWelcomeHeader')) {
      this.displayWelcomeHeader = false;
    }
    // this.userService.getCurrentUser().subscribe((user) => {
    //   this.user = user;
    // });
  }

  displayUser() {
    console.log('user : ', this.user);
  }

  handleLogout() {
    localStorage.clear();
    // this.userService.logoutUser();
    // this.router.navigate(['/login-page']);
  }

  handleHeaderRemove() {
    this.displayWelcomeHeader = false;
    localStorage.setItem('displayWelcomeHeader', 'false');
  }

}
