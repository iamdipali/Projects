import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-view-booking',
  templateUrl: './view-booking.component.html',
  styleUrls: ['./view-booking.component.css']
})
export class ViewBookingComponent implements OnInit {
  viewHistory:any;
  sub: any;
  apiUrl:string= "http://localhost:3000/expenses"
  UniqueId:string | undefined;
  bookingDetailsOfCustomer:any;
  name:any
  constructor(public activatedRoute: ActivatedRoute, private http: HttpClient,) { 
    this.name =  localStorage.getItem('Name');
  }

  ngOnInit(): void {
     this.activatedRoute.params.subscribe((params:any) => {
      debugger;
      this.UniqueId = params.UniqueId;
      this.viewHistory=params;
      debugger;
      console.log(this.viewHistory);
      this.getViewHistory();
      });
  }
  

    //  Get api method for fetch flight history data
    getViewHistory(){
      let data = {
         UniqueId: this.UniqueId
      }
      this.http.post(this.apiUrl, data).subscribe((res:any) =>
      {
        this.bookingDetailsOfCustomer = res.expenses;           
          
      })
     }
  



}
