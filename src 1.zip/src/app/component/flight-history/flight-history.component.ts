import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-flight-history',
  templateUrl: './flight-history.component.html',
  styleUrls: ['./flight-history.component.css']
})
export class FlightHistoryComponent implements OnInit {
  flightHistory: any = [];
  flightHistory0: any = [];
  apiUrl:string= "http://localhost:3000/trips"
  apiUrl0:string= "http://localhost:3000/Alltrip"
  constructor(
    private router: Router,
    private http: HttpClient,
  ) {
  }

  ngOnInit(): void {
    // Method call for fetch fligth history
    this.getHistory();
   }

  //  Get api method for fetch flight history data
   getHistory(){
    const data = {
      UserId: localStorage.getItem('id')
    }
    this.http.post(this.apiUrl, data).subscribe((res:any) =>
    {
        console.log("Post res : ", res);
        // Remove duplicate UniqueId from array
        let uniqueIds:any = [];    
        const unique = res.trips.filter((element:any) => {
          debugger;
          const isDuplicate = uniqueIds.includes(element.UniqueId);        
          if (!isDuplicate) {
            uniqueIds.push(element.UniqueId);        
            return true;
          }        
          return false;
        });
        console.log(unique);
        this.flightHistory = unique;
    })
   }


   //API to show All users Flight History [Admin Only]
   getHistoryAdmin(){
    
    this.http.get(this.apiUrl0).subscribe((res:any) =>
    {
        console.log("Post res : ", res);
        // Remove duplicate UniqueId from array
       
        // const unique = res.trips.filter((element:any) => {
        //   debugger;
        //   const isDuplicate = uniqueIds.includes(element.UniqueId);        
        //   if (!isDuplicate) {
        //     uniqueIds.push(element.UniqueId);        
        //     return true;
        //   }        
        //   return false;
        // });
        // console.log(unique);
        this.flightHistory0 = res.trips;
    })
   }

   cancelBooking(data:any){
    let datas= {
      UniqueId: data.UniqueId
   }
   this.http.post("http://localhost:3000/flightBookingCancel", datas).subscribe((res:any) =>
   {
    data.BokingStatus= false;
    this.getHistory();
     console.log(res);
   })
   }

   viewReceipt(data:any){
     this.router.navigate(['/view-bookings', data]);
   }

  alertConfirmation(data:any) {
    Swal.fire({
      title: 'Are you sure?',
      text: 'This process is irreversible.',
      icon: 'warning',
      showCancelButton: true,
      confirmButtonText: 'Yes, go ahead.',
      cancelButtonText: 'No, let me think',
    }).then((result) => {      
      if (result.value) {
        this.cancelBooking(data);
        Swal.fire('Canceled!', 'Your flight booking request is successfully Cancelled.', 'success');
      } else if (result.dismiss === Swal.DismissReason.cancel) {
        Swal.fire('Cancelled', 'Your ticket is not Cancelled.)', 'error');
      }
    });
  }
}
