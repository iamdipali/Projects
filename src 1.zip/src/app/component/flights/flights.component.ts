import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { Ng2SearchPipeModule } from 'ng2-search-filter';
@Component({
  selector: 'app-flights',
  templateUrl: './flights.component.html',
  styleUrls: ['./flights.component.css']
})
export class FlightsComponent implements OnInit {
  flightHistory:any=[];
  searchText: any;
  apiUrl:string="http://localhost:3000/flightDataGet";
  apiUrl2:string="http://localhost:3000/SeatDataGet";
  public filter:string | undefined;
  flightDetails: any;
  constructor(private router: Router,private http:HttpClient) { }

  ngOnInit(): void {
    this.getHistory();
    this.getSeatDetails();
  }

  getHistory(){
  
    this.http.get(this.apiUrl).subscribe((res:any)=>{
      console.log("Post res:",res);
      this.flightHistory=res.flightscheduledetails;
    })
  }
  goToNextBookiingDetails(){
    // console.log(flightName);
    this.router.navigate(['/flight-tickets'])
  }
  getSeatDetails(){

    this.http.get(this.apiUrl2).subscribe((res:any)=>{
      console.log("Post res:",res);
      this.flightDetails=res.SeatDetails;
    })
  }

  
}
