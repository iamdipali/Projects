import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-add-flight',
  templateUrl: './add-flight.component.html',
  styleUrls: ['./add-flight.component.css']
})
export class AddFlightComponent implements OnInit {
  display = "none";
  flightName!:string;
  origin!:string;
  destination!:string;
  duration!:number;
  Ddate!:string;
  Dtime!:string;
  Rdate!:string;
  Rtime!:string;
  //user: any[] | undefined;
 employeeData !:any;
flightHistory:any=[];
 apiUrl:string="http://localhost:3000/flightDataGet";
 apiUrl1:string="http://localhost:3000/flightDataPost"
 openModal() {
  this.display = "block";
}
onCloseHandled() {
  this.display = "none";
}
  constructor(private router: Router,
    private http:HttpClient) { 
     // this.user = [];
     this.flightName='';
     this.origin='';
     this.destination='';
     this.duration=0;
     this.Ddate='';
     this.Dtime='';
     this.Rdate='';
     this.Rtime='';

    } 

  ngOnInit(): void {
    this.getHistory();
  }
  getHistory(){

    this.http.get(this.apiUrl).subscribe((res:any)=>{
      console.log("Post res:",res);
      this.flightHistory=res.flightscheduledetails;
    })
  }
  handleFormSubmit(event:Event){
    event.preventDefault();
    
    const newData={
      flightName:this.flightName,
      origin:this.origin,
      destination:this.destination,
      duration:this.duration,
      Ddate:this.Ddate,
      Dtime:this.Dtime,
      Rdate:this.Rdate,
      Rtime:this.Rtime,
    }
    this.http.post(this.apiUrl1,newData).subscribe((res:any)=>{
      this.flightName='';
      this.origin='';
      this.destination='';
      this.duration=0;
      this.Ddate='';
      this.Dtime='';
      this.Rdate='';
      this.Rtime='';
      console.log("Post res:",res);
    })
    alert("Added Successfully!");
    let ref = document.getElementById('cancel')
    ref?.click();
  }

}
