import "./payheader.css";

export const PayHeader = () => {
  return (
    <div>
      <div className="header-md">
        <div className="header-md-img">
          <img src="./images/policylogo.png" alt="logo" className="logo-md-img"/>
        </div>
      </div>
    </div>
  );
};
